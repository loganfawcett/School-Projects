#include <vector>
#include <fstream>
#include "Menu.hpp"
#include <iostream>
#include <string>
using namespace std;

//currently working on AddPost()

class User
{
private:
	string m_username;

public:
	void SetUsername(const string& name)
	{
		m_username = name;
	}
	string GetUsername()
	{
		return m_username;
	}
	User(const string& name)
	{
		SetUsername(name);
	}
};
class Post
{
private:
	string m_contents;
	int m_authorId;

public:
	Post()
	{

	}
	Post(const string& contents, int authorID)
	{
		SetContents(contents);
		SetAuthorID(authorID);
	}
	void SetContents(const string& contents)
	{
		m_contents = contents;
	}
	string GetContents()
	{
		return m_contents;
	}
	void SetAuthorID(int id)
	{
		m_authorId =id;
	}
	int GetAuthorID()
	{
		return m_authorId;
	}
};

class Blog
{
public:
	vector<string> m_postList;
	vector<string> m_userList;
	int m_currentUser;
	void Run()
	{
		LoadFiles();
		MainMenu();
	}

private:
	void LoadFiles()
	{
		//Load Users
		ifstream Users("users.txt");
		for (int i = 0; i < 20; i++)
		{
			string temp;
			Users >> temp;
			if (temp != "")
			{
				m_userList.push_back(temp);
			}
		}
		Users.close();

		//Load Posts
		ifstream Posts("posts.txt");
		vector<string> Write;
		vector<int> NextPost;
		string temp = "";
		
		while (getline(Posts, temp))
		{
			Write.push_back(temp);
		}
		Posts.close();
		bool Finished = false;
		
		for (int n = 0; n < Write.size() - 1; n++)
		{
			if (Write[n] != "DONE")
			{
				temp += Write[n];
				
				
			}
			else
			{
				m_postList.push_back(temp);
				NextPost.push_back(n+1);
				temp = "";
			}
		}
		
	}	
	void SaveFiles()
	{
		ofstream Users("users.txt");
		for (int i = 0; i < m_userList.size(); i++)
		{
			Users << m_userList[i] << "\n";
		}
		Users.close();
		string output="";
		Post post;
		for (int i = 0; i < m_postList.size(); i++)
		{
			output += "AUTHOR_ID " + m_userList[i] + "\n" + m_postList[i] + "\n";
		}
		cout << output;
		output += "AUTHOR_ID ";
		output += post.GetAuthorID();
		output += post.GetContents();
		output += "\n";
		cout << output;
		ofstream Posts("Posts.txt");
		Posts << output;
		Posts.close();
	}

	void MainMenu()
	{
		bool done = false;
		while (!done)
		{
			int choice = Menu::ShowMenuWithPrompt({ "Register", "Login", "Exit" });
			if (choice == 1)
			{
				Register();
			}
			else if (choice == 2)
			{
				Login();
			}
			else
			{
				break;
			}
			UserMainMenu();
		}
	}
	void Register()
	{
		string temp;
		cout << "Enter a new username: ";
		cin >> temp;
		m_userList.push_back(temp);
		m_currentUser = m_userList.size() - 1;
		SaveFiles();
	}
	void Login()
	{
		vector<string> usernameList;
		for (int m = 0; m < m_userList.size(); m++)
		{
			usernameList.push_back(m_userList[m]);
			cout << m << "\t" << usernameList[m] << endl;
		}
		int choice;
		cout << "Select user number:\n";
		cin >> choice;
		if (choice >= 0 && choice < m_userList.size())
		{
			m_currentUser = choice;
		}
	}
	void UserMainMenu()
	{
		bool done = false;
		while (!done)
		{
			int choice = Menu::ShowMenuWithPrompt({ "Add Post", "View Blog Wall", "Search", "Log Out" });
			if (choice == 1)
			{
				AddPost();
			}
			else if (choice == 2)
			{
				Wall();
			}
			else if (choice == 3)
			{
				Search();
			}
			else if (choice == 4)
			{
				done = true;
			}
		}
	}

	void AddPost()
	{
		vector<string> NewPost;
		string next;
		int current = 0;
		bool finished = false;
		getline(cin, next);
		while (!finished)
		{
			getline(cin, next);
			if (next != "DONE")
			{
				NewPost.push_back(next);
				current++;
			}
			else
			{
				finished = true;
			}		
		}
		next = "";
		for (int mine = 0; mine < NewPost.size(); mine++)
		{
			next += NewPost[mine] + "\n";
		}
		Post(next, m_currentUser);
		SaveFiles();
	}
	void Wall()
	{

	}
	void Search()
	{

	}
};